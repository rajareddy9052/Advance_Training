package stmt6_3;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class Linkedlist_iterator {
	public static void main(String[] args) {
		
	
	List<Employee> list=new LinkedList<Employee>();
	Employee e1=new Employee(1, "raja", "kurnool AP");
	Employee e2=new Employee(2, "raja", "kurnool AP");
	Employee e3=new Employee(3, "raja", "kurnool AP");
	Employee e4=new Employee(4, "raja", "kurnool AP");
	
	list.add(e1);
	list.add(e2);
	list.add(e3);
	list.add(e4);
	System.out.println("forward direction: ");
	
	ListIterator<Employee> itr=list.listIterator();
	while(itr.hasNext()) {
		Employee e=itr.next();
		System.out.println(e.getE_No()+" "+e.getE_Name()+" "+e.getE_Address());
	}
	System.out.println("reverse direction: ");
	//ListIterator<Employee> itra=list.listIterator();
	while(itr.hasPrevious()) {
		
		Employee e=itr.previous();
		System.out.println(e.getE_No()+" "+e.getE_Name()+" "+e.getE_Address());
	}
	/**for(Employee e:list) {
		System.out.println(e.getE_No()+" "+e.getE_Name()+" "+e.getE_Address());
	
	}**/
	
	
}
}
