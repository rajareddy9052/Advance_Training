package stmt6_3;

public class Employee {
	private int E_No;
	private String E_Name;
	private String E_Address;
	public Employee(int e_No, String e_Name, String e_Address) {
		super();
		E_No = e_No;
		E_Name = e_Name;
		E_Address = e_Address;
	}
	public int getE_No() {
		return E_No;
	}
	public void setE_No(int e_No) {
		E_No = e_No;
	}
	public String getE_Name() {
		return E_Name;
	}
	public void setE_Name(String e_Name) {
		E_Name = e_Name;
	}
	public String getE_Address() {
		return E_Address;
	}
	public void setE_Address(String e_Address) {
		E_Address = e_Address;
	}
	

}
