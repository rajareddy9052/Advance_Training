package stmt6_2;

import java.util.HashSet;

public class Hashset_ {

	public static void main(String[] args) {  
	    HashSet<Product> set=new HashSet<Product>();  
	    Product p1=new Product("P001", "Maruti 800");
	    Product p2=new Product("P002", "Maruti vitara");
	    Product p3=new Product("P003", "Maruti swift");
	    Product p4=new Product("P004", "Maruti baleno");
	    Product p5=new Product("P005", "Maruti brezza");
	    Product p6=new Product("P006", "Maruti ertiga");
	    Product p7=new Product("P007", "Maruti s-cross");
	    Product p8=new Product("P008", "Maruti ciaz");
	    Product p9=new Product("P009", "Maruti alto");
	    Product p10=new Product("P0010", "Maruti Ignis");
	    
	    set.add(p1);
	    set.add(p2);
	    set.add(p3);
	    set.add(p4);
	    set.add(p5);
	    set.add(p6);
	    set.add(p7);
	    set.add(p8);
	    set.add(p9);
	    set.add(p10);
	    System.out.println("Product id"+"   "+"Product Name");
	    
	    for(Product p:set) {
	    	System.out.println(p.getProduct_id()+"           "+p.getProduct_Name());
	    	
	    }
	    if(set.contains(p1)) {
	    	System.out.println("Exist");
	    	}else {
	    		System.out.println("false");
	    	}
	    set.remove(p9);
	    System.out.println("Product id"+"   "+"Product Name");
	    for(Product p:set) {
	    	System.out.println(p.getProduct_id()+"           "+p.getProduct_Name());
	    	
	    }
	    
	    
}
}
