package stmt6_2;

public class Product {
	private String Product_id;
	private String Product_Name;
	public Product(String product_id, String product_Name) {
		super();
		Product_id = product_id;
		Product_Name = product_Name;
	}
	public String getProduct_id() {
		return Product_id;
	}
	public void setProduct_id(String product_id) {
		Product_id = product_id;
	}
	public String getProduct_Name() {
		return Product_Name;
	}
	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}
	

}
