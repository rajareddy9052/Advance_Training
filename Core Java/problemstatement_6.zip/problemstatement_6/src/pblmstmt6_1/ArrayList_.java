package pblmstmt6_1;

import java.util.ArrayList;

public class ArrayList_ {
	   public static void main(String args[]){  
		      ArrayList<String> list=new ArrayList<String>();  
		      list.add("Steve");
		      list.add("Tim");
		      list.add("Lucy");
		      list.add("Pat");
		      list.add("Angela");
		      list.add("Tom");
		      System.out.println(list);
		      list.add(3, "Steve");
		      System.out.println(list);
		      if(list.contains("Tom")) {
		    	  System.out.println("exist in the list");
		    	  
		      }else {
		    	  System.out.println("not in the list");
		      }
		   }  
		}

