package stmt6_4;

public class Contact {
	  private String Name;
	  private long  phoneNumber;
	  public Contact(){}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Contact(String name, long phoneNumber) {
		super();
		Name = name;
		this.phoneNumber = phoneNumber;
	}

}
