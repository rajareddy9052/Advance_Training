package stmt6_4;


import java.util.HashSet;

public class PhoneBook {
	private HashSet<Contact> phoneBook=new HashSet<Contact>();
	    public void setPhoneBook(HashSet<Contact>obj)
	    {
	        phoneBook=obj;
	    }
	    public HashSet<Contact>getPhoneBook()
	    {
	        return phoneBook;
	    }
	    public void addContact(Contact contactObj)
	    {
	        phoneBook.add(contactObj);
	    }
	    public HashSet<Contact> viewAllContacts()
	    {
	        return phoneBook;
	    }
	    public Contact viewContactGivenName(String Name)
	    {
	        Contact obj=new Contact();
	        for(Contact obj1:phoneBook)
	        {
	            if(obj1.getName()==Name)
	            {
	                obj=obj1;
	            }
	        }
	        return obj;
	    }

}
