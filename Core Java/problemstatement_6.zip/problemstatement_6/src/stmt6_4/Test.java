package stmt6_4;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

public class Test {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int i=0;
        PhoneBook objmain=new PhoneBook();
        while(i==0)
        {
            System.out.println("Menu\n1.Add Contact\n2.Search contact by Name\n3.Exit");
            System.out.println("Enter your choice: ");
            int n=Integer.parseInt(sc.nextLine());
            if(n==1)
            {
            	Contact obj=new Contact();
            	System.out.println("Add Contact: ");
            	System.out.println("Enter the Name: ");
            	obj.setName(sc.nextLine());
            	System.out.println("Enter the Phone No. : ");
                obj.setPhoneNumber(Long.parseLong(sc.nextLine()));
                objmain.addContact(obj);
            }
            if(n==2)
            {
                System.out.println("Enter the Name to search Contact:");
                String s1=sc.nextLine();
                Contact obj1=objmain.viewContactGivenName(s1);
                System.out.println("The contact is:");
                System.out.println("Name:"+obj1.getName());
                System.out.println("Phone No.:"+obj1.getPhoneNumber());
            }
            
            if(n==3)
            {
                System.exit(0);
            }
        }
    }

}
