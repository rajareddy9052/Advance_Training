package problemstatement1_2;

import java.util.Scanner;

public class TestRectangle {
	public static void main(String[] args) {
		
		
		Scanner s=new Scanner(System.in);
		System.out.println("length: ");
		double l1=s.nextDouble();
		System.out.println("breadth: ");
		double b1=s.nextDouble();
		Rectangle rect1=new Rectangle(l1, b1);
		System.out.println("Area of Rectangle 1: "+rect1.getarea());
		
		System.out.println("length: ");
		double l2=s.nextDouble();
		System.out.println("breadth: ");
		double b2=s.nextDouble();
		Rectangle rect2=new Rectangle(l2, b2);
		System.out.println("Area of Rectangle 2: "+rect2.getarea());
		System.out.println("length: ");
		double l3=s.nextDouble();
		System.out.println("breadth: ");
		double b3=s.nextDouble();
		Rectangle rect3=new Rectangle(l3, b3);
		System.out.println("Area of Rectangle 3: "+rect3.getarea());
		System.out.println("length: ");
		double l4=s.nextDouble();
		System.out.println("breadth: ");
		double b4=s.nextDouble();
		Rectangle rect4=new Rectangle(l4, b4);
		System.out.println("Area of Rectangle 4: "+rect4.getarea());
		System.out.println("length: ");
		double l5=s.nextDouble();
		System.out.println("breadth: ");
		double b5=s.nextDouble();
		Rectangle rect5=new Rectangle(l5, b5);
		System.out.println("Area of Rectangle 5: "+rect5.getarea());
		
	}

}
