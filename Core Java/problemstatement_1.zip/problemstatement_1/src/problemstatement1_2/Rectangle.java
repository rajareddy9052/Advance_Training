package problemstatement1_2;

public class Rectangle {
	private double length;
	private double breadth;
	
	public Rectangle() {
		length = 0.0;
		breadth = 0.0;
	}
	 public Rectangle(double l, double b)
	   {
	      length = l;
	      breadth  = b;
	   }

	public void set(Double l,Double b) {
		length = l;
		breadth = b;
	}
	public double getarea() {
		//return length;
		//return breadth;
		return length * breadth;
		
	}
	

}
