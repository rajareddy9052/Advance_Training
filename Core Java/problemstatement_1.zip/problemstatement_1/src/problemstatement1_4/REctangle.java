package problemstatement1_4;

public class REctangle {
	 private float length;
	   private float width;

	   public REctangle()
	   {
	      length = 0.0f;
	      width  = 0.0f;
	   }

	  
	   public REctangle(float l, float w)
	   {
	      length = l;
	      width  = w;
	   }

	  
	   public void set(float l, float w)
	   {
	      length = l;
	      width  = w;
	   }

	  
	   public double getArea()
	   {
	      return length * width;
	   }

	 
	   public double getPerimeter()
	   {
	      return 2 * (length + width);
	   }
	}
