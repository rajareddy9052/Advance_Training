package problemstatement1_4;

import java.util.Scanner;

import problemstatement1_2.Rectangle;

public class TestRectangle { 
	public static void main(String[] args)
	   {
	
	Scanner s=new Scanner(System.in);
	System.out.println("length: ");
	float l1=s.nextFloat();
	System.out.println("width: ");
	float b1=s.nextFloat();
	REctangle rect1=new REctangle(l1, b1);
	System.out.println("Area of Rectangle 1: "+rect1.getArea());
	System.out.println("Perimeter of Rectangle is "+rect1.getPerimeter());

	
	System.out.println("length: ");
	float l2=s.nextFloat();
	System.out.println("width: ");
	float b2=s.nextFloat();
	REctangle rect2=new REctangle(l2, b2);
	System.out.println("Area of Rectangle 2: "+rect2.getArea());
	System.out.println("Perimeter of Rectangle is "
            + rect2.getPerimeter());

	System.out.println("length: ");
	float l3=s.nextFloat();
	System.out.println("width: ");
	float b3=s.nextFloat();
	REctangle rect3=new REctangle(l3, b3);
	System.out.println("Area of Rectangle 3: "+rect3.getArea());
	System.out.println("Perimeter of Rectangle is "
            + rect3.getPerimeter());

	System.out.println("length: ");
	float l4=s.nextFloat();
	System.out.println("width: ");
	float b4=s.nextFloat();
	REctangle rect4=new REctangle(l4, b4);
	System.out.println("Area of Rectangle 4: "+rect4.getArea());
	System.out.println("Perimeter of Rectangle is "
            + rect4.getPerimeter());

	System.out.println("length: ");
	float l5=s.nextFloat();
	System.out.println("breadth: ");
	float b5=s.nextFloat();
	REctangle rect5=new REctangle(l5, b5);
	System.out.println("Area of Rectangle 5: "+rect5.getArea());
	System.out.println("Perimeter of Rectangle is "
            + rect5.getPerimeter());

	
	}
}
	