package com.adv;

import java.util.Scanner;

public class EvenNum {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter Num: ");
		int m=sc.nextInt();
		for(int i=0;i<=m;i++) {
			if(i%2==0) 
				System.out.print(i+" ");
			
			
		}
	}

}
