package problemstatement_18;

import java.util.HashMap;

public class RepeatingDec {

	static String fractionToDecimal(int numr, int denr) {

		String res = "";

		HashMap<Integer, Integer> mp = new HashMap<>();
		mp.clear();

		int rem = numr % denr;

		while ((rem != 0) && (!mp.containsKey(rem))) {

			mp.put(rem, res.length());

			rem = rem * 10;

			int res_part = rem / denr;
			res += String.valueOf(res_part);

			rem = rem % denr;
		}

		if (rem == 0)
			return "";
		else if (mp.containsKey(rem))
			return res.substring(mp.get(rem));

		return "";
	}

	public static void main(String[] args) {
		int numr = 1, denr = 3;
		String res = fractionToDecimal(numr, denr);
		if (res == "")
			System.out.print("There is no repeating decimal no brackets.");
		else
			System.out.print("here " + res + " is repeating decimal, put it in brackets.");
	}
}
